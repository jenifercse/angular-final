
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from  'rxjs';
import { Policy } from  './policy';
import { Department } from  './policy';
import { Exam } from  './policy';
import { Questions } from  './policy';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private httpClient: HttpClient) { }
  PHP_API_SERVER = "http://localhost";

  getAnswers(x){
      return this.httpClient.get<Policy[]>(`${this.PHP_API_SERVER}/angular-online-test/backend/api/getAnswers.php?id=${x}`); 
  }

  getQuestions(x){
    return this.httpClient.get<Policy[]>(`${this.PHP_API_SERVER}/angular-online-test/backend/api/getQuestions.php?id=${x}`);

  }

  examList(x){
    return this.httpClient.get<Policy[]>(`${this.PHP_API_SERVER}/angular-online-test/backend/api/examList.php?id=${x}`);
  }

  readPolicies(): Observable<Policy[]>{
    return this.httpClient.get<Policy[]>(`${this.PHP_API_SERVER}/angular-online-test/backend/api/read.php`);
  }
  
  deletePolicy(id: number){
    return this.httpClient.delete<Policy>(`${this.PHP_API_SERVER}/angular-online-test/backend/api/delete.php/?id=${id}`);
  }

  readDepartment(): Observable<Department[]>{
    return this.httpClient.get<Department[]>(`${this.PHP_API_SERVER}/angular-online-test/backend/api/readdept.php`);
  }
  readExam(): Observable<Exam[]>{
    return this.httpClient.get<Exam[]>(`${this.PHP_API_SERVER}/angular-online-test/backend/api/readexam.php`);
  }
  addquestion(x){
    return this.httpClient.post(this.PHP_API_SERVER+"/angular-online-test/backend/api/addquestion.php",x);
  }
  loadquestions(x)
  { 
    return this.httpClient.post(this.PHP_API_SERVER+"/angular-online-test/backend/api/loadquestions.php",x);
  }
  adduser(x)
  { 
    return this.httpClient.post(this.PHP_API_SERVER+"/angular-online-test/backend/api/adduser.php",x);
  }
}
