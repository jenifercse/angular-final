import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Exam } from './exam';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppServiceService {
	PHP_API_SERVER = " http://localhost/Angular8/angular_final/backend/api";
  constructor( private http:HttpClient) { }
   public listExam(){
    return this.http.get(`${this.PHP_API_SERVER}/Angular8/StudentTest/OnlineExam/backend/getData.php`);
  }

}
