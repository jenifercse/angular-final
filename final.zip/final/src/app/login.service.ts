import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }
  public login(data :object){
    return this.http.post('http://localhost/angular-online-test/backend/api/userdetails.php',data,{
    	  headers: {
                'Content-type': 'application/x-www-form-urlencoded',
            }

    });  
  }
}
