
//  @Author : jenifer
// @date : 4 dec 2019
// @desc : admin module to the app 

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { UsersComponent } from './users/users.component';
import { ExamsComponent } from './exams/exams.component';
import { DepartmentsComponent } from './departments/departments.component';
import { ResultsComponent } from './results/results.component';
import { QuestionsComponent } from './questions/questions.component';
import { AdduserComponent } from './adduser/adduser.component';
import { QuestionlistComponent } from './questionlist/questionlist.component';


const routes: Routes = [
							{
								path:'',
								component:AdminComponent,
								children:[
											{
												path:'',
												component:UsersComponent
											},
											{
												path:'users',
												component:UsersComponent
											},
											{
												path:'exams',
												component:ExamsComponent
											},
											{
												path:'departments',
												component:DepartmentsComponent
											},
											{
												path:'results',
												component:ResultsComponent
											},
											{
												path:'questions',
												component:QuestionsComponent
											},
											{
												path:'adduser',
												component:AdduserComponent
											},
											{
												path:'questionlist',
												component:QuestionlistComponent
											}

										]
							}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
