import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../api.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-questionlist',
  templateUrl: './questionlist.component.html',
  styleUrls: ['./questionlist.component.css']
})
export class QuestionlistComponent implements OnInit {
question; 
id;
  constructor(private service:ApiService,private router: Router) 
  { 
  }

  ngOnInit() 
  {
  
  	this.id=(localStorage.getItem('examid'));
this.loadquestions();
  	
	
  }
  loadquestions(){
    this.service.loadquestions(this.id).subscribe((x)=>
        {
          this.question = x;
        console.log(this.question);
        });
  }

}
