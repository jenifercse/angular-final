import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../api.service';
import { HttpClient } from '@angular/common/http';
import { Department } from  '../../policy';

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.css']
})
export class DepartmentsComponent implements OnInit {
departments:  Department[];
  constructor(private service:ApiService) { }

 ngOnInit() {
  	this.service.readDepartment().subscribe((departments: Department[])=>{
      this.departments = departments;
      console.log(this.departments);
    })
  }

}
