export class Exam{
	exam_name: string;
}