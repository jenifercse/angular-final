export  class  Policy {
   
    user_fname: string;
    user_lname:  string;
    user_name:  string;
    user_password:  string;
     

}
export  class  Department {
    department_code: string;
    department_name:  string;
}
export  class  Exam {
    exam_id: string;
    Exam_name:  string;
    Exam_from:  string;
    Exam_to:  string;
}
export  class  Questions {
    question:  string;
    option1:  string;
    option2:  string;
    option3:  string;
    option4:  string;
    answer:  string;
    
}

