import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { TestComponent } from './test/test.component';
import { ResultComponent } from './result/result.component';
import { TaketestComponent } from './taketest/taketest.component';


const routes: Routes = [
  {
    path:'',
    component:HomeComponent
    
  },
   {
    path:'test',
    component:TestComponent
  },{
    path:'result',
    component:ResultComponent
  },
  {
    path:'takeTest',
    component: TaketestComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
