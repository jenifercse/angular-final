import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {
	result;
  constructor() { }

  ngOnInit() {
  	var res =parseInt(localStorage.getItem('result'));
  	// console.log(localStorage.getItem('result'));
  	this.result=((res*100)/6);
  }

}
