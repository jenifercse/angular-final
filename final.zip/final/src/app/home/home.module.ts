import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home/home.component';
import { TestComponent } from './test/test.component';
import { ResultComponent } from './result/result.component';
import { NavbarComponent } from './navbar/navbar.component';
import { TaketestComponent } from './taketest/taketest.component';
import { ReactiveFormsModule,FormsModule} from '@angular/forms';

@NgModule({
  declarations: [HomeComponent, TestComponent, ResultComponent, NavbarComponent, 
  TaketestComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    FormsModule,
    ReactiveFormsModule

  ]
})
export class HomeModule { }
