import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
// import { AppServiceService } from '../../app-service.service';
import { ApiService } from '../../api.service';
import { Exam } from '../../exam';


@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
	examList:object;

  constructor(private router:Router, private service:ApiService) { }

  ngOnInit() {
  	this.service.examList(localStorage.getItem('user_id')).subscribe(data=>{
  		this.examList=data;
  		console.log(this.examList);
  	});
  }
  public takeTest(x){

    this.router.navigate(['/home/takeTest'],{
      state:{
        exam_id:x
      }
    })
  }

}
