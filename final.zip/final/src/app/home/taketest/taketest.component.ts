import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
import { FormControl,FormGroup} from '@angular/forms';


@Component({
  selector: 'app-taketest',
  templateUrl: './taketest.component.html',
  styleUrls: ['./taketest.component.css']
})
export class TaketestComponent implements OnInit {
  questionList;
  answerList;
  Question;
  result=0;
  button = "Start";
  i=0;

  answer : FormGroup=new FormGroup({
  Answers:new FormControl('')
  
});

  constructor(private router:Router, private service:ApiService) { }

  ngOnInit() {
    // console.log(history.state.exam_id);
    this.service.getQuestions(history.state.exam_id).subscribe(data=>{
      this.questionList=data;
      console.log(this.questionList);
    });
  }
  start(){
    if(this.i>=6){

      localStorage.setItem('result',this.result.toString());
      this.router.navigate(['/home/result']);
    }
    this.Question =this.questionList[this.i]['question_name'];
    this.service.getAnswers(this.questionList[this.i]['question_id']).subscribe(data=>{
      this.answerList=data;
      
      console.log(this.answerList);

    });
    this.i++;
    this.button='Next';
    if(this.i>0){
      if(this.answer.controls['Answers'].value==1){
        this.result++;
      }

       if(this.i>5){
      
     this.button="Submit";
    }
      console.log(this.result);
      // this.answer.controls['Answers'].value;
      // console.log(this.answer.controls['Answers'].value);
    }
  }

}