
//  @Author : jenifer
// @date : 4 dec 2019
// @desc : login component 

import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormBuilder,FormArray } from '@angular/forms';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
// import { AuthService } from '../../auth.service';
import { LoginService } from '../../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
returnUrl;
  constructor(private app:ApiService,private router:Router,public loginService: LoginService) { }
LoginForm : FormGroup=new FormGroup({
	user_name:new FormControl(),
	user_password:new FormControl()
});

  ngOnInit() {
  
  }

public login():any{
    this.loginService.login(this.LoginForm.value).subscribe(data=>{
    	console.log(data);
      localStorage.setItem("user_id", data[0]['user_id']);
      if(data[0]['role_id']==1){
        // localStorage.setItem('login','true');
        this.router.navigate(['/admin']);
      }
      else{
      	this.router.navigate(['/home']);
        console.log("false");
        // this.error="false";
      }
    })
  }  
 // public signup():void
	// 	 {
	// 	 	if(this.LoginForm.controls['username'].value=="admin" &&
	// 	      this.LoginForm.controls['password'].value=="admin123")
	// 	    {
	// 	  		// alert("login");
	// 	    	this.router.navigate(['./admin']);
        		
	// 	    }
	// 	    else
	// 	    {
		     
	// 	      alert("Invalid login");
	// 	    }
	// 	 }
}
