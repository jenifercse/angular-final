-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 07, 2019 at 11:23 PM
-- Server version: 8.0.17
-- PHP Version: 7.3.9-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_exam3`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `department_code` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `department_name` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_code`, `department_name`) VALUES
(5, 'J1', 'Java'),
(6, 'DB1', 'Database'),
(7, 'p1', 'PHP'),
(8, 'S1', 'Service');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL,
  `exam_name` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `exam_from` date NOT NULL,
  `exam_to` date NOT NULL,
  `passing_score` int(11) NOT NULL,
  `exam_date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `exam_created_by` int(11) NOT NULL,
  `exam_modified_by` int(11) NOT NULL,
  `exam_time_limit` int(11) NOT NULL,
  `isdeleted` int(11) DEFAULT '0',
  `passing_grade` int(11) NOT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`exam_id`, `exam_name`, `exam_from`, `exam_to`, `passing_score`, `exam_created_by`, `exam_modified_by`, `exam_time_limit`, `isdeleted`, `passing_grade`, `department_id`) VALUES
(30, 'Java Basic', '2019-11-01', '2019-11-30', 10, 1, 1, 600, 0, 5, 5),
(31, 'DBBasic', '2019-11-01', '2019-11-30', 10, 1, 0, 600, 0, 4, 6),
(32, 'Basic', '2019-11-01', '2019-11-30', 8, 1, 1, 600, 0, 5, 6);

-- --------------------------------------------------------

--
-- Table structure for table `exams_answers`
--

CREATE TABLE `exams_answers` (
  `answer_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer_name` longtext NOT NULL,
  `answer_flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams_answers`
--

INSERT INTO `exams_answers` (`answer_id`, `question_id`, `answer_name`, `answer_flag`) VALUES
(270, 123, 'class, if, void, long, Int, continue', 0),
(271, 123, 'goto, instanceof, native, finally, default, throws', 1),
(272, 123, 'try, virtual, throw, final, volatile, transient', 0),
(273, 123, 'strictfp, constant, super, implements, do', 0),
(274, 124, 'int [] myList = {\"1\", \"2\", \"3\"};', 0),
(275, 124, 'int [] myList = (5, 8, 2);', 0),
(276, 124, 'int myList [] [] = {4,9,7,0};', 0),
(277, 124, 'int myList [] = {4, 3, 7};', 1),
(278, 125, 'method', 0),
(279, 125, 'native', 1),
(280, 125, 'subclasses', 0),
(281, 125, 'reference', 0),
(282, 126, 'interface', 1),
(283, 126, 'string', 0),
(284, 126, 'Float', 0),
(285, 126, 'unsigned', 0),
(286, 127, 'Array a = new Array(5);', 0),
(287, 127, 'int [] a = {23,22,21,20,19};', 1),
(288, 127, 'int a [] = new int[5];', 0),
(289, 127, 'int a [] = new int[5];', 0),
(290, 128, 'public double methoda();', 1),
(291, 128, 'public final double methoda();', 0),
(292, 128, 'static void methoda(double d1);', 0),
(293, 128, 'protected void methoda(double d1);', 0),
(294, 129, 'Database application and the database', 1),
(295, 129, 'Data and the database', 0),
(296, 129, 'The user and the database application', 0),
(297, 129, 'Database application and SQL', 0),
(298, 130, 'IDMS', 0),
(299, 130, 'DB2', 1),
(300, 130, 'dBase-II', 0),
(301, 130, 'R:base', 0),
(302, 131, 'user data', 0),
(303, 131, 'metadata', 0),
(304, 131, 'reports', 1),
(305, 131, 'indexes', 0),
(306, 132, 'single-user database application', 1),
(307, 132, 'multiuser database application', 0),
(308, 132, 'e-commerce database application', 0),
(309, 132, 'data mining database application', 0),
(310, 133, '	single-user database application', 0),
(311, 133, 'multiuser database application', 0),
(312, 133, 'e-commerce database application', 1),
(313, 133, 'data mining database application', 0),
(314, 134, 'IDMS', 0),
(315, 134, 'Oracle', 0),
(316, 134, 'dBase-II', 0),
(317, 134, 'R:base', 1),
(318, 135, 'described', 0),
(319, 135, 'metadata compatible', 1),
(320, 135, 'self-describing', 0),
(321, 135, 'an application program', 0),
(322, 136, 'rem = 3.14 % 2.1;', 0),
(323, 136, 'rem = modf(3.14, 2.1);', 0),
(324, 136, 'rem = fmod(3.14, 2.1);', 1),
(325, 136, 'Remainder cannot be obtain in floating point division.', 0),
(326, 137, 'Internal and External', 0),
(327, 137, 'External, Internal and None', 1),
(328, 137, 'External and None', 0),
(329, 137, 'Internal', 0),
(330, 138, '* (asterisk)', 0),
(331, 138, '| (pipeline)', 0),
(332, 138, '- (hyphen)', 0),
(333, 138, '_ (underscore)', 1),
(334, 139, 'ceil(1.66)', 1),
(335, 139, 'floor(1.66)', 0),
(336, 139, 'roundup(1.66)', 0),
(337, 139, 'roundto(1.66)', 0),
(338, 140, 'float', 0),
(339, 140, 'double', 1),
(340, 140, 'long double', 0),
(341, 140, 'far double', 0),
(342, 141, 'Declaration', 1),
(343, 141, 'Definition', 0),
(344, 141, 'Function', 0),
(345, 141, 'Error', 0),
(346, 142, '1', 0),
(347, 142, '2', 0),
(348, 142, '1 and 3', 1),
(349, 142, '3', 0),
(350, 143, 'Defining', 0),
(351, 143, 'Declaring', 1),
(352, 143, 'Prototyping', 0),
(353, 143, 'Calling', 0);

-- --------------------------------------------------------

--
-- Table structure for table `exams_question`
--

CREATE TABLE `exams_question` (
  `question_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `question_name` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `question_code` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `question_type` int(11) DEFAULT '0',
  `question_date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `question_date_modified` datetime NOT NULL,
  `question_modified_by` int(11) NOT NULL,
  `question_created_by` int(11) NOT NULL,
  `essay_points` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams_question`
--

INSERT INTO `exams_question` (`question_id`, `exam_id`, `question_name`, `question_code`, `question_type`, `question_date_modified`, `question_modified_by`, `question_created_by`, `essay_points`) VALUES
(123, 30, ' Which one of these lists contains only Java programming language keywords?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(124, 30, ' Which will legally declare, construct, and initialize an array?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(125, 30, ' Which is a reserved word in the Java programming language?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(126, 30, ' Which is a valid keyword in java?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(127, 30, ' Which one of the following will declare an array and initialize it with five numbers?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(128, 30, ' Which is the valid declarations within an interface definition?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(129, 31, ' The DBMS acts as an interface between what two components of an enterprise-class database system?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(130, 31, ' Which of the following products was an early implementation of the relational model developed by E.F. Codd of IBM?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(131, 31, ' The following are components of a database except ________ .', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(132, 31, ' An application where only one user accesses the database at a given time is an example of a(n) ________ .', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(133, 31, ' An on-line commercial site such as Amazon.com is an example of a(n) ________ .', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(134, 31, 'Which of the following products was the first to implement true relational algebra in a PC DBMS?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(135, 31, ' Because it contains a description of its own structure, a database is considered to be ________ .', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(136, 32, 'Which of the following statements should be used to obtain a remainder after dividing 3.14 by 2.1 ? ', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(137, 32, ' What are the types of linkages?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(138, 32, ' 	\nWhich of the following special symbol allowed in a variable name?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(139, 32, ' How would you round off a value from 1.66 to 2.0?', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(140, 32, ' By default a real number is treated as a', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(141, 32, ' Is the following statement a declaration or definition?\nextern int i;', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(142, 32, ' Identify which of the following are declarations\n1 :	extern int x;\n2 :	float square ( float x ) { ... }\n3 :	double pow(double, double);\n', '', 0, '0000-00-00 00:00:00', 0, 1, 0),
(143, 32, ' When we mention the prototype of a function?', '', 0, '0000-00-00 00:00:00', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `transaction_code` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `time_consumed` int(11) NOT NULL,
  `check_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `transaction_date`, `transaction_code`, `user_id`, `exam_id`, `time_consumed`, `check_status`) VALUES
(107, '2019-11-08', 'a9b09a4e', 71, 30, 11, 0),
(108, '2019-11-11', '42a30db6', 70, 30, 14, 0),
(109, '2019-11-11', '46f3c04b', 70, 30, 19, 0),
(110, '2019-11-11', '48416f6c', 70, 30, 19, 0),
(111, '2019-11-11', '487decff', 70, 30, 19, 0),
(112, '2019-11-11', '48d7a06f', 70, 30, 17, 0),
(113, '2019-11-11', '4917ce5e', 70, 30, 21, 0),
(114, '2019-11-11', '495c855f', 70, 30, 22, 0),
(115, '2019-11-11', '4998a376', 70, 30, 21, 0),
(116, '2019-11-11', '49d0e5df', 70, 30, 22, 0),
(117, '2019-11-11', '4a12fabb', 70, 30, 26, 0),
(118, '2019-11-11', '4a5e2974', 70, 30, 23, 0),
(119, '2019-11-11', '4aae03b2', 70, 30, 27, 0),
(120, '2019-11-11', '4b024069', 70, 30, 26, 0),
(121, '2019-11-11', '4b53972f', 70, 30, 27, 0),
(122, '2019-11-11', '4bac963b', 70, 30, 27, 0),
(123, '2019-11-11', '4beaf1cd', 70, 30, 27, 0),
(124, '2019-11-12', '6d3b4b34', 72, 31, 12, 0),
(125, '2019-11-12', '8395eda0', 73, 30, 35, 0),
(126, '2019-11-15', 'e576c83e', 83, 30, 19, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_dtl`
--

CREATE TABLE `transaction_dtl` (
  `transaction_dtl_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `transaction_answer_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `essay` longtext,
  `transaction_code` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `transaction_question_type` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `israted` int(11) NOT NULL,
  `checked_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction_dtl`
--

INSERT INTO `transaction_dtl` (`transaction_dtl_id`, `user_id`, `question_id`, `transaction_answer_id`, `exam_id`, `essay`, `transaction_code`, `transaction_question_type`, `score`, `israted`, `checked_by`) VALUES
(930, 71, 123, 272, 30, 'null', 'a9b09a4e', 0, 0, 1, 0),
(931, 71, 124, 276, 30, 'null', 'a9b09a4e', 0, 0, 1, 0),
(932, 71, 125, 279, 30, 'null', 'a9b09a4e', 0, 1, 1, 0),
(933, 71, 126, 285, 30, 'null', 'a9b09a4e', 0, 0, 1, 0),
(934, 71, 127, 287, 30, 'null', 'a9b09a4e', 0, 1, 1, 0),
(935, 71, 128, 292, 30, 'null', 'a9b09a4e', 0, 0, 1, 0),
(936, 70, 123, 272, 30, 'null', '42a30db6', 0, 0, 1, 0),
(937, 70, 124, 276, 30, 'null', '42a30db6', 0, 0, 1, 0),
(938, 70, 125, 280, 30, 'null', '42a30db6', 0, 0, 1, 0),
(939, 70, 126, 283, 30, 'null', '42a30db6', 0, 0, 1, 0),
(940, 70, 127, 288, 30, 'null', '42a30db6', 0, 0, 1, 0),
(941, 70, 128, 292, 30, 'null', '42a30db6', 0, 0, 1, 0),
(942, 70, 128, 292, 30, 'null', '46f3c04b', 0, 0, 1, 0),
(943, 70, 128, 292, 30, 'null', '48416f6c', 0, 0, 1, 0),
(944, 70, 128, 292, 30, 'null', '487decff', 0, 0, 1, 0),
(945, 70, 128, 292, 30, 'null', '48d7a06f', 0, 0, 1, 0),
(946, 70, 128, 292, 30, 'null', '4917ce5e', 0, 0, 1, 0),
(947, 70, 128, 292, 30, 'null', '495c855f', 0, 0, 1, 0),
(948, 70, 128, 292, 30, 'null', '4998a376', 0, 0, 1, 0),
(949, 70, 128, 292, 30, 'null', '49d0e5df', 0, 0, 1, 0),
(950, 70, 128, 291, 30, 'null', '4a12fabb', 0, 0, 1, 0),
(951, 70, 128, 292, 30, 'null', '4a5e2974', 0, 0, 1, 0),
(952, 70, 128, 291, 30, 'null', '4aae03b2', 0, 0, 1, 0),
(953, 70, 128, 291, 30, 'null', '4b024069', 0, 0, 1, 0),
(954, 70, 128, 291, 30, 'null', '4b53972f', 0, 0, 1, 0),
(955, 70, 128, 291, 30, 'null', '4bac963b', 0, 0, 1, 0),
(956, 70, 128, 291, 30, 'null', '4beaf1cd', 0, 0, 1, 0),
(957, 72, 129, 296, 31, 'null', '6d3b4b34', 0, 0, 1, 0),
(958, 72, 130, 299, 31, 'null', '6d3b4b34', 0, 1, 1, 0),
(959, 72, 131, 304, 31, 'null', '6d3b4b34', 0, 1, 1, 0),
(960, 72, 132, 309, 31, 'null', '6d3b4b34', 0, 0, 1, 0),
(961, 72, 133, 311, 31, 'null', '6d3b4b34', 0, 0, 1, 0),
(962, 72, 134, 317, 31, 'null', '6d3b4b34', 0, 1, 1, 0),
(963, 72, 135, 318, 31, 'null', '6d3b4b34', 0, 0, 1, 0),
(964, 73, 123, 271, 30, 'null', '8395eda0', 0, 1, 1, 0),
(965, 73, 124, 274, 30, 'null', '8395eda0', 0, 0, 1, 0),
(966, 73, 125, 278, 30, 'null', '8395eda0', 0, 0, 1, 0),
(967, 73, 126, 282, 30, 'null', '8395eda0', 0, 1, 1, 0),
(968, 73, 127, 288, 30, 'null', '8395eda0', 0, 0, 1, 0),
(969, 73, 128, 292, 30, 'null', '8395eda0', 0, 0, 1, 0),
(970, 83, 123, 272, 30, 'null', 'e576c83e', 0, 0, 1, 0),
(971, 83, 124, 275, 30, 'null', 'e576c83e', 0, 0, 1, 0),
(972, 83, 125, 278, 30, 'null', 'e576c83e', 0, 0, 1, 0),
(973, 83, 126, 282, 30, 'null', 'e576c83e', 0, 1, 1, 0),
(974, 83, 127, 288, 30, 'null', 'e576c83e', 0, 0, 1, 0),
(975, 83, 128, 292, 30, 'null', 'e576c83e', 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `title` varchar(3) NOT NULL,
  `user_fname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `user_lname` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `department_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '4',
  `user_enabled` int(11) DEFAULT '0',
  `user_createdby` int(11) NOT NULL,
  `user_createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_modifiedby` int(11) DEFAULT NULL,
  `user_modifiedon` datetime DEFAULT NULL,
  `user_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_password` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `exam_checker` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `title`, `user_fname`, `user_lname`, `department_id`, `role_id`, `user_enabled`, `user_createdby`, `user_modifiedby`, `user_modifiedon`, `user_name`, `user_email`, `user_password`, `exam_checker`) VALUES
(1, '', 'admin', 'admin', 1, 1, 1, 0, 25, '2013-04-17 00:00:00', 'admin', '', '0192023a7bbd73250516f069df18b500', 1),
(67, '', 'test1', 'test1', 1, 4, 1, 1, NULL, NULL, 'test1', '', '5a105e8b9d40e1329780d62ea2265d8a', 0),
(71, 'Mr.', 'Sudha', 'M', 5, 4, 1, 1, NULL, NULL, 'sudha', '', '81b401c3f9a3392c0a45e9f0c8fa034e', 0),
(72, 'Mr.', 'Ram', 'M', 6, 4, 1, 1, NULL, NULL, 'ram', '', '4641999a7679fcaef2df0e26d11e3c72', 0),
(76, '', 'Aravindh', 'M', 5, 1, 1, 1, NULL, NULL, 'Aravindh', '', 'bd2a3c962b2090774104863d6875a918', 1),
(77, '', 'Jenifer', 'Y', 5, 4, 1, 1, NULL, NULL, 'Jenifer', '', '2e342c6eba58ce5f8a87aca4de7f8e74', 0),
(78, '', 'Sathish', 'J', 6, 1, 1, 1, NULL, NULL, 'Sathish', '', '078dc595e3663750846941f646f06a2d', 0),
(79, '', 'Vishal', 'M', 5, 1, 1, 1, NULL, NULL, 'Vishal', '', '8b64d2451b7a8f3fd17390f88ea35917', 1),
(80, '', 'Ajay', 'c', 5, 4, 1, 1, NULL, NULL, 'ajay', '', '29e457082db729fa1059d4294ede3909', 0),
(81, '', 'Ravi', 'S', 8, 4, 1, 1, NULL, NULL, 'Ravi', '', '63dd3e154ca6d948fc380fa576343ba6', 0),
(82, '', 'Kamaal', 'M', 5, 4, 1, 1, NULL, NULL, 'Kamaal', '', '3735c8698e9c7a6a562c9fc13fe8fcda', 0),
(83, '', 'kumar', 'kumar', 5, 4, 1, 1, NULL, NULL, 'kumar', '', '79cfac6387e0d582f83a29a04d0bcdc4', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`role_id`, `role_name`) VALUES
(1, 'Admin'),
(4, 'Staff');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `exams_answers`
--
ALTER TABLE `exams_answers`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `exams_question`
--
ALTER TABLE `exams_question`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `transaction_dtl`
--
ALTER TABLE `transaction_dtl`
  ADD PRIMARY KEY (`transaction_dtl_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `exams_answers`
--
ALTER TABLE `exams_answers`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=357;
--
-- AUTO_INCREMENT for table `exams_question`
--
ALTER TABLE `exams_question`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
--
-- AUTO_INCREMENT for table `transaction_dtl`
--
ALTER TABLE `transaction_dtl`
  MODIFY `transaction_dtl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=976;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
