<?php
  header("Access-Control-Allow-Origin:*");
  header("Access-Control-Allow-Methods: GET,POST,OPTIONS");
  header ('Content-Type: text/plain');
  error_reporting(1);
  // $postdata= file_get_contents("php://input");
  // $postData = json_decode($postdata,true);
  $row = [];
  //Create Coonection
  $conn = new mysqli ('localhost',"root","infiniti","online_exam3");
  //Check Connection
  if ($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
  }
  $result = $conn->query("SELECT answer_id, question_id,answer_name,answer_flag FROM exams_answers 
       WHERE question_id = ".$_GET[id]);
  // print_r($result);


  while($fetch = mysqli_fetch_assoc($result)){
    $row[] = $fetch;
  }

  	
    echo json_encode($row);
    exit();
?>

