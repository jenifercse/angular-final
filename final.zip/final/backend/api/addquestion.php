
<?php
require 'database.php';
// get the posted data
$post_data=file_get_contents("php://input");

if(isset($post_data) && !empty($post_data))
{
	//extract data
	$request =  json_decode($post_data,true);

	$question=$request['question'];
	$option1=$request['option1'];
	$option2=$request['option2'];
	$option3=$request['option3'];
	$option4=$request['option4'];
	$answer=$request['answer'];

	$sql="INSERT INTO t_questions (question, option1, option2, option3, option4, answer) VALUES ('$question', '$option1', '$option2', '$option3', '$option4', '$answer');";

	if(mysqli_query($con,$sql))
	{
		echo "hi inserted";
		http_response_code(201);
		// console.log($sql);
	}
	else
	{
		alert('something went wrong');

	}
	echo json_encode('hi');
}
?>