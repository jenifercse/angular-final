<?php
  header("Access-Control-Allow-Origin:*");
  header("Access-Control-Allow-Methods: GET,POST,OPTIONS");
  header ('Content-Type: text/plain');
  error_reporting(1);
  // $postdata= file_get_contents("php://input");
  // $postData = json_decode($postdata,true);
  $row = [];
  //Create Coonection
  $conn = new mysqli ('localhost',"root","infiniti","online_exam3");
  //Check Connection
  if ($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
  }
  $sql="SELECT exam_id, exam_name FROM exams 
          INNER JOIN  users ON exams.department_id = users.department_id
        WHERE users.user_id = ".$_GET['id']." ORDER BY exam_id ASC";
  // print_r($sql);

  $result = $conn->query($sql);

  while($fetch = mysqli_fetch_assoc($result)){
    $row[] = $fetch;
  }

  	
    echo json_encode($row);
    exit();
?>