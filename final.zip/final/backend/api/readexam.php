
<?php
/**
 * Returns the list of policies.
 */
require 'database.php';

$exam = [];
$sql = "SELECT * FROM exams";
// $sql="select * from users LEFT join department on users.department_id = department.department_id Left Join user_roles a ON users.role_id = a.role_id Order by user_enabled asc";

if($result = mysqli_query($con,$sql))
{
  $i = 0;
  while($row = mysqli_fetch_assoc($result))
  {
    $exam[$i]['exam_id']    =   $row['exam_id'];
    $exam[$i]['exam_name']     =   $row['exam_name'];
    $exam[$i]['exam_from']     =   $row['exam_from'];
    $exam[$i]['exam_to']     =   $row['exam_to'];
    $i++;
  }

  echo json_encode($exam);
}
else
{
  http_response_code(404);
}
?>