<?php

require 'database.php';

$policies = [];
$sql = "SELECT  user_fname,user_lname,user_name FROM users";
// $sql="select * from users LEFT join department on users.department_id = department.department_id Left Join user_roles a ON users.role_id = a.role_id Order by user_enabled asc";

if($result = mysqli_query($con,$sql))
{
  $i = 0;
  while($row = mysqli_fetch_assoc($result))
  {
    
    $policies[$i]['user_fname']    =   $row['user_fname'];
    $policies[$i]['user_lname']     =   $row['user_lname'];
    $policies[$i]['user_name']     =   $row['user_name'];
    // $policies[$i]['role_id']         =   $row['role_id'];
     // $policies[$i]['department_id']  =   $row['department_id'];
    $i++;
  }

  echo json_encode($policies);
}
else
{
  http_response_code(404);
}
?>