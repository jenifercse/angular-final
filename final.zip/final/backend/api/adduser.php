<?php
require 'database.php';


//get the posted data
$post_data=file_get_contents("php://input");

if(isset($post_data) &&  !empty($post_data))
{
	
	$request=json_decode($post_data,true);

	$user_fname=$request['user_fname'];
	$user_lname=$request['user_lname'];
	$user_name=$request['user_name'];
	$user_password=$request['user_password'];
	
	$sql="INSERT INTO users (user_fname, user_fname, user_fname, user_fname) VALUES ('$user_fname', '$user_lname', '$user_name', '$user_password');";

	if($result = mysqli_query($con,$sql))
		{
		  echo "hi inserted";
		http_response_code(201);
		}
		else
		{
		  http_response_code(404);
		}
}
?>