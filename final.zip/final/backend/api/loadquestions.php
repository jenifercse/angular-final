<?php
require 'database.php';
$question = [];

//get the posted data
$post_data=file_get_contents("php://input");

if(isset($post_data) &&  !empty($post_data))
{
	$request=json_decode($post_data,true);
	$sql="SELECT * FROM exams_question WHERE exam_id='$request'";

	if($result = mysqli_query($con,$sql))
		{
		  $i = 0;
		  while($row = mysqli_fetch_assoc($result))
		  {
		    $question[$i]['question_name'] = $row['question_name'];
		    $i++;
		  }
			
		  	echo json_encode($question);
		}
		else
		{
		  http_response_code(404);
		}
}
?>